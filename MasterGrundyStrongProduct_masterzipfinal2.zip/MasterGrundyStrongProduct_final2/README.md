# Master zip: the Grundy domination number is not multiplicative on strong products (final2)

Built 14 October 2026, 20:49 UTC, from creelie/grundy-strong-product, main at 4153d84 (release
v1.0.0 with its DOI recorded).

- Paper: "The Grundy domination number is not multiplicative on strong products", Deep
  Bhattacharjee (sole author), 6 pages.
- DOI of release v1.0.0: [10.5281/zenodo.23378021](https://doi.org/10.5281/zenodo.23378021);
  all versions: [10.5281/zenodo.23378020](https://doi.org/10.5281/zenodo.23378020).
- Target journal: The Electronic Journal of Combinatorics, where the conjecture was posed.
  Fallbacks: Discrete Mathematics; Journal of Graph Theory.

## What is proved

Conjecture 22 of Brešar, Bujtás, Gologranc, Klavžar, Košmrlj, Patkós, Tuza and Vizer (Electron. J.
Combin. 23(4) (2016), #P4.34) says γ_gr(G ⊠ H) = γ_gr(G) γ_gr(H) for all graphs G and H. It is false.

- **Theorem 1.2.** Let H_21 be the graph on {0, ..., 20} with u ~ v when |u − v| ≡ 2 (mod 3).
  Then γ_gr(K_{2,2,2}) = 2, γ_gr(H_21) = 10 and γ_gr(K_{2,2,2} ⊠ H_21) ≥ 21 > 20.
- **Theorem 1.3.** γ_gr(K_{2,2,2} ⊠ H_N) ≥ N for every N (proved by hand), and
  γ_gr(H_N) = ⌊(N + 1)/3⌋ + 3 for 6 ≤ N ≤ 63 (exhaustive search), so every N from 21 to 63 gives a
  counterexample; for N = 63 the ratio is at least 21/16.
- Circular cliques K_{3n/(n+1)} with n = 9, 10, 11 are counterexamples too (Remark 5.3).

The lower bounds are proved by hand for every N. The bound γ_gr(H_21) ≤ 10 is a search over 5479
dominated sets; it is certified in Lean 4 (25 theorems, standard axioms only, no `native_decide`)
and checked by a C program and a Python program written independently. The values for 22 ≤ N ≤ 63
come from the C program; its output is in `repository/verification/grundy_HN.txt`.

## What is open

- Question 5.1 of the paper: does γ_gr(H_N) = ⌊(N + 1)/3⌋ + 3 hold for all N ≥ 6? If it does, the
  ratio γ_gr(K_{2,2,2} ⊠ H_N) / (γ_gr(K_{2,2,2}) γ_gr(H_N)) is at least N / (2⌊(N + 1)/3⌋ + 6),
  which tends to 3/2.
- Question 5.2: is the ratio γ_gr(G ⊠ H) / (γ_gr(G) γ_gr(H)) bounded over all graphs, and which
  graphs G satisfy the conjecture for every H? Forests do (Bell, Driscoll, Krop and Wolff, 2021);
  the octahedron does not.

## Contents

| Path | What it is |
| --- | --- |
| `journal-EJC/ejc-manuscript-final2.pdf` | Manuscript in the journal's format (`e-jc.sty`), 7 pages |
| `journal-EJC/ejc-manuscript-source-final2.zip` | Its LaTeX source, `e-jc.sty` and the three PNG figures |
| `journal-EJC/cover-letter.md` | Cover letter |
| `journal-EJC/submission-checklist.md` | Submission steps and what only the author can confirm |
| `preprint/grundy-strong-product_final2.pdf` | The preprint (amsart), as released |
| `preprint/grundy-strong-product_final2-tex.zip` | Its LaTeX source with PNG figures |
| `preprint/grundy-strong-product_final2-arxiv.tar.gz` | The arXiv upload |
| `PRIORITY-RECHECK-2026-10-14.md` | Priority recheck, 20:38–20:42 UTC on 14 October 2026 |
| `repository/` | The repository at 4153d84: Lean certificates, C and Python checks, scripts and the first priority check |

## Before submitting

The manuscript states no funding and no competing interests. Please confirm both, and that the
paper is not under consideration elsewhere; see `journal-EJC/submission-checklist.md`.
