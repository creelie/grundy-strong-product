# Priority recheck: the strong product conjecture for Grundy domination

Rechecked 14 October 2026, 20:38–20:42 UTC, before the release of v1.0.0. The first check
(19:55–20:05 UTC the same day) is in `repository/PRIORITY-CHECK.md`.

| Source | Search | Result |
|---|---|---|
| arXiv API | `all:"Grundy domination"`; `all:Grundy AND all:"strong product"`; `all:"dominating sequences"`; newest first | nothing new since the first check; the newest Grundy domination paper is arXiv:2608.21225 (21 August 2026, the domination game on Sierpiński graphs), which does not touch the conjecture |
| Semantic Scholar | papers citing doi:10.37236/6269 (18), arXiv:2104.05665 (5) and arXiv:2212.04565 (1) | the same papers as in the first check; none claims a counterexample |
| Zenodo | `"Grundy domination"`; `"strong product conjecture"` | no records |
| OpenRefute ([the-omega-institute/trureturing](https://github.com/the-omega-institute/trureturing)) | the 9 problem and library files added or changed between commit 3a1bdf0 and commit abe0ff2 (20:35 UTC, 14 October 2026) | quantum channels, statistical mechanics and voter models; nothing on Grundy domination |

Conclusion: as of 20:42 UTC on 14 October 2026 we found no earlier disproof of Conjecture 22 of
Brešar et al. (Electron. J. Combin. 23(4) (2016), #P4.34) and no earlier appearance of the
counterexample K_{2,2,2} ⊠ H_21.
