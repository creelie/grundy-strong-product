# The Electronic Journal of Combinatorics: submission checklist

Manuscript: "The Grundy domination number is not multiplicative on strong products" (Deep
Bhattacharjee, sole author).

Submit through the journal's site, https://www.combinatorics.org/ojs/index.php/eljc/about/submissions
(register or log in, then "Make a submission"). The journal asks for a PDF prepared with its style file
`e-jc.sty`; the LaTeX source is needed after acceptance.

## Files in this folder

| File | Use |
| --- | --- |
| `ejc-manuscript-final2.pdf` | Manuscript for the first submission, in the journal's format |
| `ejc-manuscript-source-final2.zip` | LaTeX source with `e-jc.sty` and the three PNG figures, for after acceptance |
| `cover-letter.md` | Cover letter; paste it into the comments for the editor |

## What only the author can confirm

- [ ] No funding: the manuscript reports none.
- [ ] No competing interests.
- [ ] The declaration of generative AI use at the end of the manuscript is accurate.
- [ ] The manuscript is not under consideration at another journal (the journal's checklist asks this).
- [ ] The licence line: the manuscript uses "Released under the CC BY license (International 4.0)";
      the journal also offers CC BY-ND or plain copyright with the author.

## Already done

- Abstract that names the result, MSC 2020 codes (05C69, 05C76), ASCII-only source as the journal asks.
- Every reference and DOI checked online on 14 October 2026.
- The Lean proof and the axiom audit pass (25 theorems, standard axioms only); the C and Python
  checks pass (see the repository README).
- Priority recheck dated 14 October 2026 in this zip.

Fallback journals, in order: Discrete Mathematics; Journal of Graph Theory.
