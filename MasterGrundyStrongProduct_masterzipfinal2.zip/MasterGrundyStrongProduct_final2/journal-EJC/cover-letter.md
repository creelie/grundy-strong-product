Deep Bhattacharjee
Formerly, Electro-Gravitational Space Propulsion Laboratory (EGSPL)
Bhubaneswar, Odisha 751030, India
d.bhattacharjee@erl-forschung.de · itsdeep@live.com · ORCID 0000-0003-0466-750X

To the Editors, The Electronic Journal of Combinatorics

Dear Editors,

I submit the manuscript "The Grundy domination number is not multiplicative on strong products" for consideration in The Electronic Journal of Combinatorics.

In this journal, Brešar, Bujtás, Gologranc, Klavžar, Košmrlj, Patkós, Tuza and Vizer (Electron. J. Combin. 23(4) (2016), #P4.34) proved that γ_gr(G ⊠ H) ≥ γ_gr(G) γ_gr(H) and conjectured equality for all graphs (their Conjecture 22). Bell, Driscoll, Krop and Wolff later proved it when one factor is a forest (Electron. J. Combin. 28(2) (2021), #P2.12), and a claimed proof for all graphs (arXiv:2212.04565) was withdrawn by its authors.

The manuscript shows that the conjecture is false. For the octahedron K_{2,2,2} and the graph H_21 on {0, …, 20} in which u and v are adjacent when |u − v| ≡ 2 (mod 3), we have γ_gr(K_{2,2,2}) = 2 and γ_gr(H_21) = 10, while K_{2,2,2} ⊠ H_21 has a legal sequence of length 21. The lower bound for the product is a short explicit argument that works for a whole family; the bound γ_gr(H_21) ≤ 10 is an exhaustive search, which we certified in the Lean 4 proof assistant and checked with two independent programs. The same family gives counterexamples for 21 ≤ N ≤ 63, with ratio up to 21/16, and circulant second factors (circular cliques K_{3n/(n+1)}) work as well.

The Lean development, the programs and their outputs are archived with the source of the paper on Zenodo (doi:10.5281/zenodo.23378021) and at https://github.com/creelie/grundy-strong-product.

The manuscript is not under consideration elsewhere. There is no funding to report and no competing interest. The use of a generative AI tool is declared in the manuscript.

Yours sincerely,
Deep Bhattacharjee
